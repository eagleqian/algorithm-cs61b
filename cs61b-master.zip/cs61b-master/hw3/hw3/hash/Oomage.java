package hw3.hash;

public interface Oomage {
    void draw(double x, double y, double scalingFactor);
} 
